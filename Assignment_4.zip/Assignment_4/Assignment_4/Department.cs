﻿namespace Assignment_4
{
    public enum Department
    {
        Electronics,
        Home,
        Books,
        Toys
    }
}
