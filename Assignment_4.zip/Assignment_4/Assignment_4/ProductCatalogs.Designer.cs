﻿namespace Assignment_4
{
    partial class Catalog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.DataStoreBox = new System.Windows.Forms.GroupBox();
            this.timerInterval = new System.Windows.Forms.NumericUpDown();
            this.autoSaveCHKBOX = new System.Windows.Forms.CheckBox();
            this.LoadBTN = new System.Windows.Forms.Button();
            this.FilePathTXTBOX = new System.Windows.Forms.TextBox();
            this.FilePathLBL = new System.Windows.Forms.Label();
            this.createProductBTN = new System.Windows.Forms.Button();
            this.ProductGrid = new System.Windows.Forms.DataGridView();
            this.NameCOL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PriceCOL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DepartmentCOL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.filterBOX = new System.Windows.Forms.TextBox();
            this.FilterLBL = new System.Windows.Forms.Label();
            this.saveTimer = new System.Windows.Forms.Timer(this.components);
            this.DataStoreBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.timerInterval)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProductGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // DataStoreBox
            // 
            this.DataStoreBox.Controls.Add(this.timerInterval);
            this.DataStoreBox.Controls.Add(this.autoSaveCHKBOX);
            this.DataStoreBox.Controls.Add(this.LoadBTN);
            this.DataStoreBox.Controls.Add(this.FilePathTXTBOX);
            this.DataStoreBox.Controls.Add(this.FilePathLBL);
            this.DataStoreBox.Location = new System.Drawing.Point(13, 13);
            this.DataStoreBox.Name = "DataStoreBox";
            this.DataStoreBox.Size = new System.Drawing.Size(358, 100);
            this.DataStoreBox.TabIndex = 0;
            this.DataStoreBox.TabStop = false;
            this.DataStoreBox.Text = "Data Store";
            // 
            // timerInterval
            // 
            this.timerInterval.Location = new System.Drawing.Point(175, 47);
            this.timerInterval.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.timerInterval.Name = "timerInterval";
            this.timerInterval.Size = new System.Drawing.Size(87, 20);
            this.timerInterval.TabIndex = 4;
            this.timerInterval.Value = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.timerInterval.ValueChanged += new System.EventHandler(this.timerInterval_ValueChanged);
            // 
            // autoSaveCHKBOX
            // 
            this.autoSaveCHKBOX.AutoSize = true;
            this.autoSaveCHKBOX.Location = new System.Drawing.Point(62, 47);
            this.autoSaveCHKBOX.Name = "autoSaveCHKBOX";
            this.autoSaveCHKBOX.Size = new System.Drawing.Size(106, 17);
            this.autoSaveCHKBOX.TabIndex = 3;
            this.autoSaveCHKBOX.Text = "Auto Save Every";
            this.autoSaveCHKBOX.UseVisualStyleBackColor = true;
            this.autoSaveCHKBOX.CheckedChanged += new System.EventHandler(this.autoSaveCHKBOX_CheckedChanged);
            // 
            // LoadBTN
            // 
            this.LoadBTN.Location = new System.Drawing.Point(268, 18);
            this.LoadBTN.Name = "LoadBTN";
            this.LoadBTN.Size = new System.Drawing.Size(75, 23);
            this.LoadBTN.TabIndex = 2;
            this.LoadBTN.Text = "Load";
            this.LoadBTN.UseVisualStyleBackColor = true;
            this.LoadBTN.Click += new System.EventHandler(this.loadBTN_Click);
            // 
            // FilePathTXTBOX
            // 
            this.FilePathTXTBOX.Location = new System.Drawing.Point(62, 20);
            this.FilePathTXTBOX.Name = "FilePathTXTBOX";
            this.FilePathTXTBOX.Size = new System.Drawing.Size(200, 20);
            this.FilePathTXTBOX.TabIndex = 1;
            // 
            // FilePathLBL
            // 
            this.FilePathLBL.AutoSize = true;
            this.FilePathLBL.Location = new System.Drawing.Point(7, 20);
            this.FilePathLBL.Name = "FilePathLBL";
            this.FilePathLBL.Size = new System.Drawing.Size(48, 13);
            this.FilePathLBL.TabIndex = 0;
            this.FilePathLBL.Text = "File Path";
            // 
            // createProductBTN
            // 
            this.createProductBTN.Location = new System.Drawing.Point(12, 159);
            this.createProductBTN.Name = "createProductBTN";
            this.createProductBTN.Size = new System.Drawing.Size(104, 23);
            this.createProductBTN.TabIndex = 1;
            this.createProductBTN.Text = "Create Product";
            this.createProductBTN.UseVisualStyleBackColor = true;
            this.createProductBTN.Click += new System.EventHandler(this.createProductBTN_Click);
            // 
            // ProductGrid
            // 
            this.ProductGrid.AllowUserToOrderColumns = true;
            this.ProductGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ProductGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NameCOL,
            this.PriceCOL,
            this.DepartmentCOL});
            this.ProductGrid.Location = new System.Drawing.Point(12, 189);
            this.ProductGrid.Name = "ProductGrid";
            this.ProductGrid.Size = new System.Drawing.Size(614, 249);
            this.ProductGrid.TabIndex = 4;
            // 
            // NameCOL
            // 
            this.NameCOL.HeaderText = "Name";
            this.NameCOL.Name = "NameCOL";
            this.NameCOL.ReadOnly = true;
            // 
            // PriceCOL
            // 
            this.PriceCOL.HeaderText = "Price";
            this.PriceCOL.Name = "PriceCOL";
            this.PriceCOL.ReadOnly = true;
            // 
            // DepartmentCOL
            // 
            this.DepartmentCOL.HeaderText = "Department";
            this.DepartmentCOL.Name = "DepartmentCOL";
            this.DepartmentCOL.ReadOnly = true;
            // 
            // filterBOX
            // 
            this.filterBOX.Location = new System.Drawing.Point(489, 163);
            this.filterBOX.Name = "filterBOX";
            this.filterBOX.Size = new System.Drawing.Size(138, 20);
            this.filterBOX.TabIndex = 3;
            this.filterBOX.TextChanged += new System.EventHandler(this.filterBOX_TextChanged);
            // 
            // FilterLBL
            // 
            this.FilterLBL.AutoSize = true;
            this.FilterLBL.Location = new System.Drawing.Point(454, 166);
            this.FilterLBL.Name = "FilterLBL";
            this.FilterLBL.Size = new System.Drawing.Size(29, 13);
            this.FilterLBL.TabIndex = 2;
            this.FilterLBL.Text = "Filter";
            // 
            // saveTimer
            // 
            this.saveTimer.Interval = 500;
            this.saveTimer.Tick += new System.EventHandler(this.saveTimer_Tick);
            // 
            // Catalog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(639, 450);
            this.Controls.Add(this.FilterLBL);
            this.Controls.Add(this.filterBOX);
            this.Controls.Add(this.ProductGrid);
            this.Controls.Add(this.createProductBTN);
            this.Controls.Add(this.DataStoreBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "Catalog";
            this.Text = "Catalog";
            this.DataStoreBox.ResumeLayout(false);
            this.DataStoreBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.timerInterval)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProductGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox DataStoreBox;
        private System.Windows.Forms.NumericUpDown timerInterval;
        private System.Windows.Forms.CheckBox autoSaveCHKBOX;
        private System.Windows.Forms.Button LoadBTN;
        private System.Windows.Forms.TextBox FilePathTXTBOX;
        private System.Windows.Forms.Label FilePathLBL;
        private System.Windows.Forms.Button createProductBTN;
        private System.Windows.Forms.DataGridView ProductGrid;
        private System.Windows.Forms.TextBox filterBOX;
        private System.Windows.Forms.Label FilterLBL;
        private System.Windows.Forms.DataGridViewTextBoxColumn NameCOL;
        private System.Windows.Forms.DataGridViewTextBoxColumn PriceCOL;
        private System.Windows.Forms.DataGridViewTextBoxColumn DepartmentCOL;
        private System.Windows.Forms.Timer saveTimer;
    }
}

