﻿using System.Collections.Generic;
using System.Windows.Forms;

namespace Assignment_4
{
    public partial class Catalog : Form
    {
        private Classes.Catalog productCatalog;
        public Catalog()
        {
            InitializeComponent();
            productCatalog = new Classes.Catalog();
        }

        private void loadBTN_Click(object sender, System.EventArgs e)
        {
            productCatalog = Classes.DataStore.Load(FilePathTXTBOX.Text);
            LoadDataGrid();
        }        
        private void timerInterval_ValueChanged(object sender, System.EventArgs e)
        {
            saveTimer.Interval = (int)timerInterval.Value;
        }
        private void saveTimer_Tick(object sender, System.EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(FilePathTXTBOX.Text))
                Classes.DataStore.Save(productCatalog, "CatalogAutoSave.txt");
            else
                Classes.DataStore.Save(productCatalog, FilePathTXTBOX.Text);

                
        }

        private void createProductBTN_Click(object sender, System.EventArgs e)
        {
            using(NewProduct newProduct = new NewProduct())
            {
                newProduct.CreateNewProduct = AddProduct;
                newProduct.ShowDialog();
            }
        }        
        private void autoSaveCHKBOX_CheckedChanged(object sender, System.EventArgs e)
        {
            if (autoSaveCHKBOX.Checked)
                saveTimer.Start();
            else if (!autoSaveCHKBOX.Checked)
                saveTimer.Stop();
        }
        private void AddProduct(object sender, Classes.ProductEventArgs e)
        {
            productCatalog.Add(e.NewProduct);
            LoadDataGrid();
        }
        private void LoadDataGrid()
        {
            ProductGrid.Rows.Clear();

            if (filterBOX.Text.Equals(null) || filterBOX.Text.Equals(""))
                WriteCatalogData(productCatalog.GetAllProducts());
            else
                WriteCatalogData(productCatalog.GetProducts(filterBOX.Text));
        }
        private void WriteCatalogData(IEnumerable<Classes.Product> products)
        {
            foreach (Classes.Product product in products)
            {
                ProductGrid.Rows.Add(product.Name, product.Price, product.Department);
            }
        }

        private void filterBOX_TextChanged(object sender, System.EventArgs e)
        {
            LoadDataGrid();
        }
    }
}
    