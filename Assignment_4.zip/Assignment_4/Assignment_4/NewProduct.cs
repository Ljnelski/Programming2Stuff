﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_4
{   
    public partial class NewProduct : Form
    {
        public EventHandler<Classes.ProductEventArgs> CreateNewProduct { get; set; }
        public NewProduct()
        {
            InitializeComponent();
        }

        private void createBTN_Click(object sender, EventArgs e)
        {
            if (CheckForEmptyName())
            {
                Classes.Product product = new Classes.Product(nameBOX.Text, priceBOX.Value, (Department)catagoryBOX.SelectedItem);
                CreateNewProduct(this, new Classes.ProductEventArgs(product));
                ClearFields();
            }           
        }       
        private bool CheckForEmptyName()
        {
            if (String.IsNullOrWhiteSpace(nameBOX.Text))
                return false;
            else
                return true;            
        }
        private void ClearFields()
        {
            nameBOX.Clear();
            priceBOX.Value = 0.00m;
        }
        private void NewProduct_Load(object sender, EventArgs e)
        {
            catagoryBOX.Items.Add(Department.Books);
            catagoryBOX.Items.Add(Department.Electronics);
            catagoryBOX.Items.Add(Department.Home);
            catagoryBOX.Items.Add(Department.Toys);
        }

        private void cancelBTN_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
