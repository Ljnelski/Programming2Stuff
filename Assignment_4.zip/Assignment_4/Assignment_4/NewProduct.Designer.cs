﻿namespace Assignment_4
{
    partial class NewProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.newProductGRPBOX = new System.Windows.Forms.GroupBox();
            this.priceBOX = new System.Windows.Forms.NumericUpDown();
            this.nameBOX = new System.Windows.Forms.TextBox();
            this.catagoryBOX = new System.Windows.Forms.ComboBox();
            this.PriceLBL = new System.Windows.Forms.Label();
            this.CatagoryLBL = new System.Windows.Forms.Label();
            this.NameLabel = new System.Windows.Forms.Label();
            this.createBTN = new System.Windows.Forms.Button();
            this.cancelBTN = new System.Windows.Forms.Button();
            this.newProductGRPBOX.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.priceBOX)).BeginInit();
            this.SuspendLayout();
            // 
            // newProductGRPBOX
            // 
            this.newProductGRPBOX.Controls.Add(this.priceBOX);
            this.newProductGRPBOX.Controls.Add(this.nameBOX);
            this.newProductGRPBOX.Controls.Add(this.catagoryBOX);
            this.newProductGRPBOX.Controls.Add(this.PriceLBL);
            this.newProductGRPBOX.Controls.Add(this.CatagoryLBL);
            this.newProductGRPBOX.Controls.Add(this.NameLabel);
            this.newProductGRPBOX.Location = new System.Drawing.Point(12, 12);
            this.newProductGRPBOX.Name = "newProductGRPBOX";
            this.newProductGRPBOX.Size = new System.Drawing.Size(313, 100);
            this.newProductGRPBOX.TabIndex = 0;
            this.newProductGRPBOX.TabStop = false;
            this.newProductGRPBOX.Text = "Product";
            // 
            // priceBOX
            // 
            this.priceBOX.DecimalPlaces = 2;
            this.priceBOX.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.priceBOX.Location = new System.Drawing.Point(62, 69);
            this.priceBOX.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.priceBOX.Name = "priceBOX";
            this.priceBOX.Size = new System.Drawing.Size(105, 20);
            this.priceBOX.TabIndex = 5;
            // 
            // nameBOX
            // 
            this.nameBOX.Location = new System.Drawing.Point(62, 16);
            this.nameBOX.Name = "nameBOX";
            this.nameBOX.Size = new System.Drawing.Size(234, 20);
            this.nameBOX.TabIndex = 1;
            // 
            // catagoryBOX
            // 
            this.catagoryBOX.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.catagoryBOX.FormattingEnabled = true;
            this.catagoryBOX.Location = new System.Drawing.Point(62, 42);
            this.catagoryBOX.Name = "catagoryBOX";
            this.catagoryBOX.Size = new System.Drawing.Size(234, 21);
            this.catagoryBOX.TabIndex = 3;
            // 
            // PriceLBL
            // 
            this.PriceLBL.AutoSize = true;
            this.PriceLBL.Location = new System.Drawing.Point(7, 71);
            this.PriceLBL.Name = "PriceLBL";
            this.PriceLBL.Size = new System.Drawing.Size(31, 13);
            this.PriceLBL.TabIndex = 4;
            this.PriceLBL.Text = "Price";
            // 
            // CatagoryLBL
            // 
            this.CatagoryLBL.AutoSize = true;
            this.CatagoryLBL.Location = new System.Drawing.Point(7, 45);
            this.CatagoryLBL.Name = "CatagoryLBL";
            this.CatagoryLBL.Size = new System.Drawing.Size(49, 13);
            this.CatagoryLBL.TabIndex = 2;
            this.CatagoryLBL.Text = "Catagory";
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Location = new System.Drawing.Point(7, 20);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(35, 13);
            this.NameLabel.TabIndex = 0;
            this.NameLabel.Text = "Name";
            // 
            // createBTN
            // 
            this.createBTN.Location = new System.Drawing.Point(250, 122);
            this.createBTN.Name = "createBTN";
            this.createBTN.Size = new System.Drawing.Size(75, 23);
            this.createBTN.TabIndex = 2;
            this.createBTN.Text = "Create";
            this.createBTN.UseVisualStyleBackColor = true;
            this.createBTN.Click += new System.EventHandler(this.createBTN_Click);
            // 
            // cancelBTN
            // 
            this.cancelBTN.Location = new System.Drawing.Point(169, 122);
            this.cancelBTN.Name = "cancelBTN";
            this.cancelBTN.Size = new System.Drawing.Size(75, 23);
            this.cancelBTN.TabIndex = 1;
            this.cancelBTN.Text = "Cancel";
            this.cancelBTN.UseVisualStyleBackColor = true;
            this.cancelBTN.Click += new System.EventHandler(this.cancelBTN_Click);
            // 
            // NewProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(337, 157);
            this.Controls.Add(this.cancelBTN);
            this.Controls.Add(this.createBTN);
            this.Controls.Add(this.newProductGRPBOX);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "NewProduct";
            this.Text = "NewProduct";
            this.Load += new System.EventHandler(this.NewProduct_Load);
            this.newProductGRPBOX.ResumeLayout(false);
            this.newProductGRPBOX.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.priceBOX)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox newProductGRPBOX;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label PriceLBL;
        private System.Windows.Forms.Label CatagoryLBL;
        private System.Windows.Forms.NumericUpDown priceBOX;
        private System.Windows.Forms.TextBox nameBOX;
        private System.Windows.Forms.ComboBox catagoryBOX;
        private System.Windows.Forms.Button createBTN;
        private System.Windows.Forms.Button cancelBTN;
    }
}