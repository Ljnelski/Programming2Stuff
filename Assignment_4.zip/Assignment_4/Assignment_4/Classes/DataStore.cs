﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Assignment_4.Classes
{
    public static class DataStore
    {
        public static Catalog Load(string file)
        {
            try {
                using (StreamReader reader = new StreamReader(file))
                {
                    Catalog newCatalog = new Catalog();
                    while (!reader.EndOfStream)
                    {
                        try
                        {
                            Product newProduct = new Product();

                            newProduct.Name = reader.ReadLine();
                            newProduct.Price = decimal.Parse(reader.ReadLine());
                            newProduct.Department = (Department)Enum.Parse(typeof(Department), reader.ReadLine());

                            newCatalog.Add(newProduct);
                        }
                        catch (Exception)
                        {
                            throw;
                        }
                    }
                    return newCatalog;
                }
            }
            catch 
            {
                return new Catalog();
            }
        }
        public static void Save(Catalog catalog, string filePath)
        {
            List<Product> products = new List<Product>(catalog.GetAllProducts());
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                foreach (Product product in products)
                {
                    writer.WriteLine(product.Name);
                    writer.WriteLine(product.Price.ToString());
                    writer.WriteLine(product.Department.ToString());
                }
            }
        }
    }
}
