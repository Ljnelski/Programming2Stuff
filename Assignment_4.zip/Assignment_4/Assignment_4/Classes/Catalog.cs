﻿using System.Collections.Generic;

namespace Assignment_4.Classes
{
    public class Catalog
    {
        private List<Product> _list = new List<Product>();
        public void Add(Product product)
        {
            _list.Add(product);
        }
        public IEnumerable<Product> GetAllProducts()
        {
            return _list;
        }
        public IEnumerable<Product> GetProducts(string filter)
        {
            List<Product> products = new List<Product>();
            foreach (Product product in _list)
            {
                if (product.Name.ToLower().Contains(filter.ToLower()))
                    products.Add(product);
            }
            return products;
        }

    }
}
