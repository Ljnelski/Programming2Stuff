﻿using System;

namespace Assignment_4.Classes
{
    public class ProductEventArgs : EventArgs
    {
        public Product NewProduct { get; }
        public ProductEventArgs(Product product)
        {
            NewProduct = product;
        }
    }
}
