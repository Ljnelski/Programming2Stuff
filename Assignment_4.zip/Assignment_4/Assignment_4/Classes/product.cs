﻿namespace Assignment_4.Classes
{
    public class Product
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
        public Department Department { get; set; }       

        public Product()
        {
            ;
        }
        public Product(string name, decimal price, Department depart)
        {
            Name = name;
            Price = price;
            Department = depart;
        }
    }
}
