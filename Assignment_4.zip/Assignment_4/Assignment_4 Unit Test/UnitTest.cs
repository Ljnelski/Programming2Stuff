﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Assignment_4;
using Assignment_4.Classes;
using System.Collections.Generic;

namespace Assignment_4_Unit_Test
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void Create_A_Product()
        {
            Product product = new Product("ITEM", 2.99M, Department.Books);

            Assert.AreEqual("ITEM", product.Name);
            Assert.AreEqual(2.99M, product.Price);
            Assert.AreEqual(Department.Books, product.Department);
        }
        [TestMethod]
        public void Create_Catalog_Add_Product()
        {
            Assignment_4.Classes.Catalog catalog = new Assignment_4.Classes.Catalog();
            Product product = new Product("ITEM", 2.99M, Department.Books);

            catalog.Add(product);
            List<Product> list = (List<Product>)catalog.GetProducts("ITem");

            Assert.AreEqual(product, list[0]);
        }
        [TestMethod]
        public void Filter_Catalog()
        {
            Assignment_4.Classes.Catalog catalog = new Assignment_4.Classes.Catalog();
            catalog.Add(new Product("AAA", 2.99M, Department.Books));
            catalog.Add(new Product("BCC", 2.99M, Department.Books));
            catalog.Add(new Product("ABB", 2.99M, Department.Books));            
            catalog.Add(new Product("DRC", 2.99M, Department.Books));

            List<Product> list = (List<Product>)catalog.GetProducts("a");

            Assert.AreEqual("AAA", list[0].Name);
            Assert.AreEqual("ABB", list[1].Name);
        }
        [TestMethod]
        public void Get_List_From_Catalog()
        {
            Assignment_4.Classes.Catalog catalog = new Assignment_4.Classes.Catalog();
            catalog.Add(new Product("AAA", 2.99M, Department.Books));
            catalog.Add(new Product("ABB", 2.99M, Department.Books));
            catalog.Add(new Product("BCC", 2.99M, Department.Books));
            catalog.Add(new Product("DRC", 2.99M, Department.Books));

            List<Product> list = (List<Product>)catalog.GetAllProducts();

            Assert.AreEqual("AAA", list[0].Name);
            Assert.AreEqual("ABB", list[1].Name);
            Assert.AreEqual("BCC", list[2].Name);
            Assert.AreEqual("DRC", list[3].Name);
        }
        [TestMethod]
        public void Save_Load_Data_From_Data_Store()
        {
            Assignment_4.Classes.Catalog SaveCatalog = new Assignment_4.Classes.Catalog();           
            Product book1 = new Product("WW2", 6.99M, Department.Books);
            Product book2 = new Product("How to fish", 8.99M, Department.Books);
            Product book3 = new Product("Animals", 7.99M, Department.Books);
            Product book4 = new Product("Trains", 12.99M, Department.Books);
            

            SaveCatalog.Add(book1);
            SaveCatalog.Add(book2);
            SaveCatalog.Add(book3);
            SaveCatalog.Add(book4);

            DataStore.Save(SaveCatalog, "Testfile.txt");
            Assignment_4.Classes.Catalog loadCatalog;
            loadCatalog = DataStore.Load("Testfile.txt");
            List<Product> listOfProducts = (List<Product>)loadCatalog.GetAllProducts();

            Assert.AreEqual(book1.Name, listOfProducts[0].Name);
            Assert.AreEqual(book2.Name, listOfProducts[1].Name);
            Assert.AreEqual(book3.Name, listOfProducts[2].Name);
            Assert.AreEqual(book4.Name, listOfProducts[3].Name);

            Assert.AreEqual(book1.Price, listOfProducts[0].Price);
            Assert.AreEqual(book2.Price, listOfProducts[1].Price);
            Assert.AreEqual(book3.Price, listOfProducts[2].Price);
            Assert.AreEqual(book4.Price, listOfProducts[3].Price);

            Assert.AreEqual(book1.Department, listOfProducts[0].Department);
            Assert.AreEqual(book2.Department, listOfProducts[1].Department);
            Assert.AreEqual(book3.Department, listOfProducts[2].Department);
            Assert.AreEqual(book4.Department, listOfProducts[3].Department);
        }
        [TestMethod]
        public void LoadCatalog()
        {

        }
    }
}
