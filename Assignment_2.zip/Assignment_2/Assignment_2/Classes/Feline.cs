﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2.Classes
{
    public abstract class Feline : Animal
    {
        public Feline(string name) : base(name)
        {
            ;
        }
        public Feline() : base()
        {

        }
        public override int LegCount()
        {
            return 4;
        }
    }
}
