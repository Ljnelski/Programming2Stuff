﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment_2.Interfaces;

namespace Assignment_2.Classes
{
    public class Zoo : IPlace
    {
        public bool AddAnimal(IAnimal animal) //WHY THE FUCK DOES THIS NEED IANIMAL to be Public (if you see this I forgot to ask you about itq)
        {
            if (!animal.IsWild())
                return false;
            else if (animal.IsWild())
                animal.Location = Location.Zoo;
            return true;
        }
    }
}
