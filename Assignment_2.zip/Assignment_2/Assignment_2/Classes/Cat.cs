﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2.Classes
{
    public class Cat : Feline
    {
        public Cat(string name) : base(name)
        {
            ;
        }
        public Cat() : base()
        {
            ;
        }
        public override bool IsWild()
        {
            return false;
        }

        public override string MakeSound()
        {
            return "Meow";
        }
    }
}
