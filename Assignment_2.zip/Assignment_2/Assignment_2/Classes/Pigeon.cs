﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2.Classes
{
    public class Pigeon : Bird, Interfaces.IFlight
    {
        public Pigeon(string name) : base(name)
        {
            ;
        }        
        public Pigeon() : base()
        {
            ;
        }
        public override bool IsWild()
        {
            return true;
        }
        public override string MakeSound()
        {
            return "Coo";
        }
        public void FlyAway()
        {
            Location = Location.Wild;
        }
    }
}
