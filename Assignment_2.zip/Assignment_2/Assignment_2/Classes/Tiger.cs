﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2.Classes
{
    public class Tiger : Feline
    {
        public Tiger(string name) : base(name)
        {
            ;
        }
        public Tiger() : base()
        {
            ;
        }
        public override bool IsWild()
        {
            return true;
        }
        public override string MakeSound()
        {
            return "Roar";
        }
    }
}
