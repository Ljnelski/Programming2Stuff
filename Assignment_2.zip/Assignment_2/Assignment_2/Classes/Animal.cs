﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment_2.Interfaces;

namespace Assignment_2.Classes
{
    public abstract class Animal : IAnimal
    {
        public Location Location { get; set; }
        public string Name { get; }
        public Animal(string name)
        {
            Name = name;
            Location = Location.Wild;
        }
        public Animal()
        {
            Location = Location.Wild;
        }
        public abstract bool IsWild();
        public abstract int LegCount();
        public abstract string MakeSound();
        public override string ToString()
        {
            string typeName = GetType().ToString().Substring(21);
            return $"The {typeName} goes {MakeSound()} in the {Location}";
        }
    }
}
