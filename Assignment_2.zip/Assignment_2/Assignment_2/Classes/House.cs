﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment_2.Interfaces;

namespace Assignment_2.Classes
{
    public class House : IPlace
    {
        public bool AddAnimal(IAnimal animal)
        {
            if (animal.IsWild())
                return false;
            else if (!animal.IsWild())
                animal.Location = Location.House;
            return true;
        }
    }
}
