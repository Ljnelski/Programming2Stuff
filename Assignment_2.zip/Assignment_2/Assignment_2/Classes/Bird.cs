﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment_2.Interfaces;

namespace Assignment_2.Classes
{
    public abstract class Bird : Animal
    {
        public Bird(string name) : base(name)
        {
            ;
        }
        public Bird() : base()
        {

        }
        public override int LegCount()
        {
            return 2;
        }
    }
}
