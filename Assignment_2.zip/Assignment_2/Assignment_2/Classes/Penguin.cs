﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment_2.Interfaces;

namespace Assignment_2.Classes
{
    public class Penguin : Bird
    {
        public Penguin(string name) : base(name)
        {
            ;
        }
        public Penguin() : base()
        {
            ;
        }
        public override bool IsWild()
        {
            return true;
        }
        public override string MakeSound()
        {
            return "Honk";
        }
    }
}
