﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Classes.Cat cat = new Classes.Cat();
            Classes.Tiger tiger = new Classes.Tiger();
            Classes.Pigeon pigeon = new Classes.Pigeon();
            Classes.Penguin penguin = new Classes.Penguin();

            Interfaces.IAnimal[] animals = new Interfaces.IAnimal[4];
            animals[0] = cat;
            animals[1] = tiger;
            animals[2] = pigeon;
            animals[3] = penguin;

            foreach (Interfaces.IAnimal animal in animals)
                Console.WriteLine(animal);


            Classes.Zoo zoo = new Classes.Zoo();
            zoo.AddAnimal(tiger);
            zoo.AddAnimal(pigeon);
            zoo.AddAnimal(penguin);

            Classes.House house = new Classes.House();
            house.AddAnimal(cat);

            Console.WriteLine();
            foreach (Interfaces.IAnimal animal in animals)
                Console.WriteLine(animal);

            pigeon.FlyAway();
            Console.WriteLine();
            Console.WriteLine(pigeon.ToString());

            Console.ReadKey();
        }
    }
}
