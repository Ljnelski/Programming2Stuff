﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace Assignment_2_Unit_Test
{
    [TestClass]
    public class UnitTest
    {
        //------------------Penguin Tests------------------
        [TestMethod]
        public void PenguinReturnStringInWild_InZoo_InHouse()
        {
            Assignment_2.Classes.Penguin testPenguin = new Assignment_2.Classes.Penguin();
            Assignment_2.Classes.Zoo zoo = new Assignment_2.Classes.Zoo();
            Assignment_2.Classes.House house = new Assignment_2.Classes.House();

            Assert.AreEqual("The Penguin goes Honk in the Wild", testPenguin.ToString());

            zoo.AddAnimal(testPenguin);
            Assert.AreEqual("The Penguin goes Honk in the Zoo", testPenguin.ToString());

            house.AddAnimal(testPenguin);
            Assert.AreEqual("The Penguin goes Honk in the Zoo", testPenguin.ToString());
        }
        [TestMethod]
        public void PenguinNamedSteve()
        {
            Assignment_2.Classes.Penguin testPenguin = new Assignment_2.Classes.Penguin("Steve");
            Assert.AreEqual("Steve", testPenguin.Name);
        }
        [TestMethod]
        public void PenguinLegs()
        {
            Assignment_2.Classes.Penguin testPenguin = new Assignment_2.Classes.Penguin();
            Assert.AreEqual(2, testPenguin.LegCount());
        }

        //---------------------Pigeon Tests------------------------
        [TestMethod]
        public void PideonReturnStringInWild_InZoo_InHouse_AfterFlyAway()
        {
            Assignment_2.Classes.Pigeon testPigeon = new Assignment_2.Classes.Pigeon();
            Assignment_2.Classes.Zoo zoo = new Assignment_2.Classes.Zoo();
            Assignment_2.Classes.House house = new Assignment_2.Classes.House();

            Assert.AreEqual("The Pigeon goes Coo in the Wild", testPigeon.ToString());

            zoo.AddAnimal(testPigeon);
            Assert.AreEqual("The Pigeon goes Coo in the Zoo", testPigeon.ToString());

            house.AddAnimal(testPigeon);
            Assert.AreEqual("The Pigeon goes Coo in the Zoo", testPigeon.ToString());

            testPigeon.FlyAway();
            Assert.AreEqual("The Pigeon goes Coo in the Wild", testPigeon.ToString());
        }
        [TestMethod]
        public void PigeonNamedGod()
        {
            Assignment_2.Classes.Pigeon testPigeon = new Assignment_2.Classes.Pigeon("God");
            Assert.AreEqual("God", testPigeon.Name);
        }
        [TestMethod]
        public void PigeonLegs()
        {
            Assignment_2.Classes.Pigeon testPigeon = new Assignment_2.Classes.Pigeon();
            Assert.AreEqual(2, testPigeon.LegCount());
        }

        //---------------------Cat Tests------------------------
        [TestMethod]
        public void CatReturnStringInWild_InZoo_InHouse()
        {
            Assignment_2.Classes.Cat testCat = new Assignment_2.Classes.Cat();
            Assignment_2.Classes.Zoo zoo = new Assignment_2.Classes.Zoo();
            Assignment_2.Classes.House house = new Assignment_2.Classes.House();

            Assert.AreEqual("The Cat goes Meow in the Wild", testCat.ToString());

            zoo.AddAnimal(testCat);
            Assert.AreEqual("The Cat goes Meow in the Wild", testCat.ToString());

            house.AddAnimal(testCat);
            Assert.AreEqual("The Cat goes Meow in the House", testCat.ToString());
        }
        [TestMethod]
        public void CatNamedGentic_mistake()
        {
            Assignment_2.Classes.Cat testCat = new Assignment_2.Classes.Cat("Genetic mistake");
            Assert.AreEqual("Genetic mistake", testCat.Name);
        }
        [TestMethod]
        public void CatLegs()
        {
            Assignment_2.Classes.Cat testPigeon = new Assignment_2.Classes.Cat();
            Assert.AreEqual(4, testPigeon.LegCount());
        }

        //---------------------Tiger Tests------------------------
        [TestMethod]
        public void TigerReturnStringInWild_InZoo_InHouse()
        {
            Assignment_2.Classes.Tiger testTiger = new Assignment_2.Classes.Tiger();
            Assignment_2.Classes.Zoo zoo = new Assignment_2.Classes.Zoo();
            Assignment_2.Classes.House house = new Assignment_2.Classes.House();

            Assert.AreEqual("The Tiger goes Roar in the Wild", testTiger.ToString());

            zoo.AddAnimal(testTiger);
            Assert.AreEqual("The Tiger goes Roar in the Zoo", testTiger.ToString());

            house.AddAnimal(testTiger);
            Assert.AreEqual("The Tiger goes Roar in the Zoo", testTiger.ToString());
        }
        [TestMethod]
        public void TigerNamedGlen()
        {
            Assignment_2.Classes.Tiger testTiger = new Assignment_2.Classes.Tiger("Glen");
            Assert.AreEqual("Glen", testTiger.Name);
        }
        [TestMethod]
        public void TigerLegs()
        {
            Assignment_2.Classes.Tiger testTiger = new Assignment_2.Classes.Tiger();
            Assert.AreEqual(4, testTiger.LegCount());
        }
    }
}
