﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

//1. Do you need catch statment to have brackets after
namespace Assignment_3_UnitTest
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void AddProductToProductList()
        {            
            try
            {
                Assignment_3.ProductList productList = new Assignment_3.ProductList();
                Assignment_3.Product product = new Assignment_3.Product(1, "Dry Erase Markers", 5.99f);
                productList.AddProduct(product);
                if (productList.Count <= 0)                
                    throw new Exception("List is empty when it shouldn't be");
                
            }
            catch (Exception)
            {
                Assert.Fail(); 
            }
        }
        [TestMethod]
        public void RemoveProductFromProductList()
        {
            Assignment_3.Product[] products = {
                new Assignment_3.Product(1, "Dry Erase Markers", 5.99f),
                new Assignment_3.Product(2, "Laptop", 399.99f),
                new Assignment_3.Product(3, "Dromeasaur Tooth", 349.99f),
                new Assignment_3.Product(4, "Fan", 24.99f)
            };
            
            Assignment_3.ProductList list = new Assignment_3.ProductList(products);
            Assert.AreEqual("ID: 1, Name: Dry Erase Markers, Price: 5.99", list.FindProduct(1).ToString());
            Assert.AreEqual("ID: 2, Name: Laptop, Price: 399.99", list.FindProduct(2).ToString());
            
            list.RemoveProducts(1);
            list.RemoveProducts(1);
            Assert.IsFalse(list.FindProduct(1) == products[1]);
            Assert.IsFalse(list.FindProduct(2) == products[2]);
        }
        [TestMethod]
        public void AddProductToProductQueue()
        {            
            try
            {                
                Assignment_3.ProductQueue queue = new Assignment_3.ProductQueue();
                Assignment_3.Product product = new Assignment_3.Product(1, "Dry Erase Markers", 5.99f);
                queue.AddProduct(product);
                if (queue.Count <= 0)
                    throw new Exception("Queue is empty when it shouldn't be");
            }
            catch (Exception) 
            {
                Assert.Fail();
            }
        }
        [TestMethod]
        public void RemoveProductFromProductQueue()
        {
            Assignment_3.Product[] products = {
                new Assignment_3.Product(1, "Dry Erase Markers", 5.99f),
                new Assignment_3.Product(2, "Laptop", 399.99f),
                new Assignment_3.Product(3, "Dromeasaur Tooth", 349.99f),
                new Assignment_3.Product(4, "Fan", 24.99f)
            };
            Assignment_3.ProductQueue queue = new Assignment_3.ProductQueue(products);
            queue.RemoveProducts(2);
            Assert.AreEqual(null, queue.FindProduct(1));
            Assert.AreEqual(null, queue.FindProduct(2));
        }
        [TestMethod]
        public void AddProductToProductStack()
        {
            try
            {
                Assignment_3.ProductStack stack = new Assignment_3.ProductStack();
                Assignment_3.Product product = new Assignment_3.Product(1, "Bluetooth Mouse", 26.99f);
                stack.AddProduct(product);
                if (stack.Count <= 0)
                    throw new Exception("Stack is empty when it shouldn't be");
            }
            catch 
            {
                Assert.Fail();
            }
            
        }
        [TestMethod]
        public void RemoveProductFromProductStack()
        {
            Assignment_3.Product[] products = {
                new Assignment_3.Product(1, "Dry Erase Markers", 5.99f),
                new Assignment_3.Product(2, "Laptop", 399.99f),
                new Assignment_3.Product(3, "Dromeasaur Tooth", 349.99f),
                new Assignment_3.Product(4, "Fan", 24.99f)
            };
            Assignment_3.ProductStack stack = new Assignment_3.ProductStack(products);
            Assert.AreEqual("ID: 3, Name: Dromeasaur Tooth, Price: 349.99", stack.FindProduct(3).ToString());
            Assert.AreEqual("ID: 4, Name: Fan, Price: 24.99", stack.FindProduct(4).ToString());
            stack.RemoveProducts(2);
            Assert.AreEqual(null, stack.FindProduct(3));
            Assert.AreEqual(null, stack.FindProduct(4));
        }
        [TestMethod]
        public void AddProductToProductDictionary()
        {
            try
            {
                Assignment_3.Product product = new Assignment_3.Product(3, "Dromeasaur Tooth", 349.99f);
                Assignment_3.ProductDictionary dictionary = new Assignment_3.ProductDictionary();
                dictionary.AddProduct(product);
                if (dictionary.Count <= 0)
                    throw new Exception("Dictionary is empty when is shouldnt be");
            }
            catch
            {
                Assert.Fail();
            }
        }
        [TestMethod]
        public void RemoveProductFromProductDictionary()
        {
            Assignment_3.Product[] products = {
                new Assignment_3.Product(1, "Dry Erase Markers", 5.99f),
                new Assignment_3.Product(2, "Laptop", 399.99f),
                new Assignment_3.Product(3, "Dromeasaur Tooth", 349.99f),
                new Assignment_3.Product(4, "Fan", 24.99f)
            };
            Assignment_3.ProductDictionary dictionary = new Assignment_3.ProductDictionary(products);
            Assert.AreEqual("ID: 1, Name: Dry Erase Markers, Price: 5.99", dictionary.FindProduct(1).ToString());
            Assert.AreEqual("ID: 2, Name: Laptop, Price: 399.99", dictionary.FindProduct(2).ToString());           
            dictionary.RemoveProducts(1);
            dictionary.RemoveProducts(2);
            Assert.AreEqual(null, dictionary.FindProduct(1));
            Assert.AreEqual(null, dictionary.FindProduct(2));
        }
    }
}
