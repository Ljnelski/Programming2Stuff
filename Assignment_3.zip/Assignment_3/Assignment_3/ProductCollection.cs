﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Assignment_3
{
    public abstract class ProductCollection
    {
        public virtual int Count { get; }
        public abstract void AddProduct(Product product);
        public abstract void DisplayProducts();
        public abstract Product FindProduct(int id);
        public void LoadFromFile(string fileName)
        {
            using (StreamReader reader = new StreamReader(fileName))
            {
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    string[] lineData = line.Split(' ');
                    try
                    {
                        Product newProduct = new Product(int.Parse(lineData[0]), lineData[1], float.Parse(lineData[2]));
                        AddProduct(newProduct);
                    }
                    catch
                    {
                        System.Console.WriteLine($"Error in product format, line: '{line}' is unreadable");
                    }                    
                }
            }
        }
        public abstract void RemoveProducts(int number);
    }
}
