﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3
{
    public class ProductList : ProductCollection
    {
        private List<Product> _products;
        public override int Count { 
            get
            {
                return _products.Count;
            }
        }
        public ProductList()
        {
            _products = new List<Product>();
        }
        public ProductList(Product[] product)
        {
            _products = new List<Product>(product);
        }
        public override void AddProduct(Product product)
        {            
            _products.Add(product);
        }
        public override void DisplayProducts()
        {
            foreach (Product product in _products)            
                Console.WriteLine(product.ToString());            
        }
        public override Product FindProduct(int id)
        {
            foreach (Product product in _products)
            {
                if (product.ID == id)
                    return product;
            }
            return null;
        }
        public override void RemoveProducts(int number)
        {
            _products.Remove(_products[number]);
        }
    }
}
