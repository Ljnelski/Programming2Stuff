﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3
{
    public class ProductQueue : ProductCollection
    {
        private Queue<Product> _products;
        public override int Count
        {
            get
            {
                return _products.Count;
            }
        }
        public ProductQueue()
        {
            _products = new Queue<Product>();
        }
        public ProductQueue(Product[] product)
        {
            _products = new Queue<Product>(product);
        }
        public override void AddProduct(Product product)
        {
            _products.Enqueue(product);
        }
        public override void DisplayProducts()
        {
            foreach (var product in _products)            
                Console.WriteLine(product.ToString());            
        }
        public override Product FindProduct(int id)
        {
            foreach (Product product in _products)
            {
                if (product.ID == id)
                    return product;
            }
            return null;
        }
        public override void RemoveProducts(int number)
        {
            for (int i = 0; i < number; i++)            
                _products.Dequeue();            
        }
    }
}
