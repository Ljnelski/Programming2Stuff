﻿using System;
using System.Collections.Generic;

namespace Assignment_3
{
    public class ProductDictionary : ProductCollection
    {
        Dictionary<int, Product> _products;
        public override int Count
        {
            get
            {
                return _products.Count;
            }
        }
        public ProductDictionary()
        {
            _products = new Dictionary<int,Product>();
        }
        public ProductDictionary(Product[] product)
        {
            _products = new Dictionary<int, Product>();
            for (int i = 0; i < product.Length; i++)            
                _products.Add(product[i].ID, product[i]);            
        }
        public override void AddProduct(Product product)
        {
            _products.Add(product.ID, product);
        }
        public override void DisplayProducts()
        {
            foreach (var product in _products)
            {
                Console.WriteLine(product.Value.ToString());
            }
        }
        public override Product FindProduct(int id)
        {
            Product product;
            if (_products.ContainsKey(id))
                _products.TryGetValue(id, out product);
            else
                product = null;
            return product;
        }
        public override void RemoveProducts(int number)
        {
            _products.Remove(number);
        }
    }
}
