﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1 - List");
            Console.WriteLine("2 - Queue");
            Console.WriteLine("3 - Stack");
            Console.WriteLine("4 - Dictionary");
            Console.Write("\nEnter an option: ");
            int option = int.Parse(Console.ReadLine());
            ProductCollection products = null;
            switch (option) 
            { 
                case 1: 
                    products = new ProductList();
                    break;
                case 2:
                    products = new ProductQueue();
                    break;
                case 3:
                    products = new ProductStack();
                    break;
                case 4:
                    products = new ProductDictionary();
                    break;
            }
            products.LoadFromFile("brokenList.txt");
            products.DisplayProducts();
            Console.Write("\nEnter a number to remove: ");
            int removeNumber = int.Parse(Console.ReadLine());
            products.RemoveProducts(removeNumber);
            products.DisplayProducts();
            Console.Write("\nEnter a number to find: ");
            int findNumber = int.Parse(Console.ReadLine());
            Console.WriteLine($"Found: {products.FindProduct(findNumber)}");
            Console.Write("\npress any key to exit");
            Console.ReadKey();
        }
    }
}
