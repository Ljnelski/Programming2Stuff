﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1
{
    public class BankAccount
    {
        public static double _bankIntrestRate;

        public BankAccount(string ownerFirstName, string ownerLastName, double initalBalance)
        {
            AccountOwner = new Person();
            AccountOwner._firstName = ownerFirstName;
            AccountOwner._lastName = ownerLastName;
            AccountBalance = initalBalance;
        }
        public Person AccountOwner { get; private set; } // Auto Implemented Propertie
        public double AccountBalance { get; private set; } // Auto Implemented Propertie

        public void Deposit(double amount)
        {
            AccountBalance += amount; //uses private set property to increase the money in account
        }
        public void Withdrawl(double amount)
        {
            if (amount < AccountBalance)
            {
                AccountBalance -= amount; //uses private set property to decrease the money in account
    }
            else
                ; //insufficent funds to withdrawl
        }
        public void DepositIntrest()
        {
            AccountBalance *= _bankIntrestRate;
        }
        public override string ToString()
        {
            string accountInfo = $"{AccountOwner.ToString()}\nAccount Balance: {AccountBalance}";
            return accountInfo;
        }
    }   
}
