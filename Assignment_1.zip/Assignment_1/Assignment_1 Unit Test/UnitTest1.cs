﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Assignment_1_Unit_Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void InitalizeEmptyBankAccount()
        {
            Assignment_1.BankAccount testAccount = new Assignment_1.BankAccount("Liam", "Nelski", 0.0);
            Assert.AreEqual(0.0, testAccount.AccountBalance);
        }
        [TestMethod]
        public void InitalizeBankAccount_56Dollars67Cents()
        {
            Assignment_1.BankAccount testAccount = new Assignment_1.BankAccount("Liam", "Nelski", 56.67);
            Assert.AreEqual(56.67, testAccount.AccountBalance);
        }
        [TestMethod]
        public void InitalizeBankAccount_22Dollars88Cents()
        {
            Assignment_1.BankAccount testAccount = new Assignment_1.BankAccount("Liam", "Nelski", 22.88);
            Assert.AreEqual(22.88, testAccount.AccountBalance);
        }
        [TestMethod]
        public void Deposit_20Dollars_InEmptyAccount()
        {
            Assignment_1.BankAccount testAccount = new Assignment_1.BankAccount("Liam", "Nelski", 0.0);
            testAccount.Deposit(20.0);
            Assert.AreEqual(20.0, testAccount.AccountBalance);
        }
        [TestMethod]
        public void Deposit_27Dollars43Cents_InEmptyAccount()
        {
            Assignment_1.BankAccount testAccount = new Assignment_1.BankAccount("Liam", "Nelski", 0.0);
            testAccount.Deposit(27.43);
            Assert.AreEqual(27.43, testAccount.AccountBalance);
        }
        [TestMethod]
        public void Deposit_45Dollars_InAccountWith_20Dollars()
        {
            Assignment_1.BankAccount testAccount = new Assignment_1.BankAccount("Liam", "Nelski", 20.0);
            testAccount.Deposit(45);
            Assert.AreEqual(65, testAccount.AccountBalance);
        }
        [TestMethod]
        public void Deposit_20Dollars15Cents_InAccountWith_10Dollars15Cents()
        {
            Assignment_1.BankAccount testAccount = new Assignment_1.BankAccount("Liam", "Nelski", 10.15);
            testAccount.Deposit(20.15);
            Assert.AreEqual(30.30, testAccount.AccountBalance, 0.0001);
        }
        [TestMethod]
        public void Withdrawl_10Dollars_FromAccountWith_20Dollars()
        {
            Assignment_1.BankAccount testAccount = new Assignment_1.BankAccount("Liam", "Nelski", 20.0);
            testAccount.Withdrawl(10.0);
            Assert.AreEqual(10.0, testAccount.AccountBalance);
        }
        [TestMethod]
        public void Withdrawl_10Dollars20Cents_FromAccountWith_20Dollars()
        {
            Assignment_1.BankAccount testAccount = new Assignment_1.BankAccount("Liam", "Nelski", 20.0);
            testAccount.Withdrawl(10.20);
            Assert.AreEqual(9.8, testAccount.AccountBalance);
        }
        [TestMethod]
        public void Deposit_2Point5PercentIntrestToEmptyAccount()
        {
            Assignment_1.BankAccount testAcccount = new Assignment_1.BankAccount("Liam", "Nelski", 0.0);
            Assignment_1.BankAccount._bankIntrestRate = 1.025;
            testAcccount.DepositIntrest();
            Assert.AreEqual(0, testAcccount.AccountBalance);
        }
        [TestMethod]
        public void Deposit_2Point5PercentIntrestToAccountWith_100Dollars()
        {
            Assignment_1.BankAccount testAcccount = new Assignment_1.BankAccount("Liam", "Nelski", 100);
            Assignment_1.BankAccount._bankIntrestRate = 1.025;
            testAcccount.DepositIntrest();
            Assert.AreEqual(102.5, testAcccount.AccountBalance, 0.0001);
        }
    }
}
